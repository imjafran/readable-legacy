=== Readable ===
Contributors: Waseem Senjer, iamjafran
Donate link: http://shamekh.ws
Tags: rss, widget , plugin
Requires at least: 2.6
Tested up to: 2.8
Stable tag: 1.1

A widget for your blog to make your blog Rss link readable .

== Description ==

A widget to add the "ADD" icon of Rss online readers to your blog like Google Reader , newsgator , bloglines , myAOL ..... etc 
see the screenshot tab . 
This Plugin Coded by : Waseem Senjer , for any suggestions , you can email me at waseem.senjer[at]gmail.com

== Installation ==



1. Upload `readable` folder to the `/wp-content/plugins/` directory
1. Activate the plugin through the 'Plugins' menu in WordPress
1. In your "Widget" menu add the widget to your sidebar and configure it .
1. enjoy :)



== Screenshots ==

1. The Widget in the Work :)
2. Choose the services that you want to appear  .


